class Nota:
    def __init__(self, valor:float, quantidade:float):
        self.valor_nota = valor
        self.quantidade_nota = quantidade
